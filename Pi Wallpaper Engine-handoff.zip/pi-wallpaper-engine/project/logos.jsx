// Pi Wallpaper Engine — logo marks (v2)
// Anchor: a tiny single-board computer playing video. No π glyph, no raspberry trademark.
// Each concept renders an SVG icon at 256×256 with rounded corners.
//
// Concepts:
//   A · Board    — top-down SBC silhouette with GPIO pin strip + play triangle on the die
//   B · Chip     — IC chip with screen on its die; pins splay out
//   C · HDMI     — HDMI plug profile + motion lines flowing out (= signal/wallpaper)
//   D · TinyTV   — micro CRT/screen with a circuit body, eye-catching at all sizes
//   E · Loop     — cable forming a play-triangle loop around a small device dot
//   F · Pixel    — chunky 16-grid pixel-art mini-computer (favicon/CLI partner)

const PALETTES = {
  violet:  { ink: '#0E1116', paper: '#F4EFE6', accent: '#7C5CFF', accent2: '#B7A7FF' },
  cyan:    { ink: '#0B1418', paper: '#EAF4F2', accent: '#22D3C7', accent2: '#8FF0E6' },
  phosphor:{ ink: '#0B130F', paper: '#E8F3E5', accent: '#3DDC84', accent2: '#A8EBC1' },
  amber:   { ink: '#15110A', paper: '#F6EFD9', accent: '#F5A524', accent2: '#FBD37A' },
};

// ─────────────────────────────────────────────────────────────
// A · Board — top-down SBC silhouette + GPIO pins + play triangle
// ─────────────────────────────────────────────────────────────
function IconBoard({ p = PALETTES.phosphor, radius = 64 }) {
  return (
    <svg viewBox="0 0 256 256" width="100%" height="100%">
      <rect x="0" y="0" width="256" height="256" rx={radius} fill={p.ink} />
      {/* board silhouette */}
      <rect x="32" y="56" width="192" height="144" rx="10" fill={p.paper} />
      {/* mounting holes */}
      {[[48,72],[208,72],[48,184],[208,184]].map(([x,y],i)=>(
        <circle key={i} cx={x} cy={y} r="5" fill={p.ink} />
      ))}
      {/* GPIO header (top edge) */}
      <g fill={p.ink}>
        {Array.from({length:20}).map((_,i)=>(
          <rect key={i} x={64 + i*6.4} y="62" width="3.6" height="10" rx="1" />
        ))}
      </g>
      {/* SoC die in centre w/ play triangle */}
      <rect x="92" y="100" width="72" height="72" rx="6" fill={p.ink} />
      <path d="M118 122 L150 138 L118 154 Z" fill={p.accent} />
      {/* USB/HDMI side ports */}
      <rect x="32" y="120" width="14" height="20" fill={p.ink} />
      <rect x="32" y="148" width="14" height="20" fill={p.ink} />
      <rect x="210" y="116" width="14" height="28" fill={p.ink} />
      {/* tiny trace */}
      <path d="M164 136 L196 136" stroke={p.accent} strokeWidth="3" />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// B · Chip — IC chip with screen on its die
// ─────────────────────────────────────────────────────────────
function IconChip({ p = PALETTES.violet, radius = 64 }) {
  // pin generator
  const pins = [];
  const len = 18;
  for (let i = 0; i < 5; i++) {
    // top
    pins.push(<rect key={`t${i}`} x={68 + i*24 + 4} y="32" width="14" height={len} rx="2" fill={p.paper} />);
    // bottom
    pins.push(<rect key={`b${i}`} x={68 + i*24 + 4} y={256-32-len} width="14" height={len} rx="2" fill={p.paper} />);
    // left
    pins.push(<rect key={`l${i}`} x="32" y={68 + i*24 + 4} width={len} height="14" rx="2" fill={p.paper} />);
    // right
    pins.push(<rect key={`r${i}`} x={256-32-len} y={68 + i*24 + 4} width={len} height="14" rx="2" fill={p.paper} />);
  }
  return (
    <svg viewBox="0 0 256 256" width="100%" height="100%">
      <rect x="0" y="0" width="256" height="256" rx={radius} fill={p.ink} />
      {pins}
      {/* chip body */}
      <rect x="64" y="64" width="128" height="128" rx="10" fill={p.paper} />
      {/* corner divot (orientation mark) */}
      <circle cx="78" cy="78" r="6" fill={p.ink} />
      {/* screen on die */}
      <rect x="84" y="92" width="88" height="62" rx="5" fill={p.ink} />
      <rect x="92" y="100" width="72" height="46" rx="2" fill={p.accent} opacity="0.85" />
      {/* play triangle inside the screen */}
      <path d="M118 110 L142 123 L118 136 Z" fill={p.ink} />
      {/* label line */}
      <rect x="88" y="168" width="80" height="6" rx="2" fill={p.ink} />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// C · HDMI — HDMI plug profile + motion lines
// ─────────────────────────────────────────────────────────────
function IconHDMI({ p = PALETTES.cyan, radius = 64 }) {
  return (
    <svg viewBox="0 0 256 256" width="100%" height="100%">
      <rect x="0" y="0" width="256" height="256" rx={radius} fill={p.ink} />
      {/* HDMI trapezoid */}
      <path
        d="M62 84 L194 84 L210 116 L194 148 L62 148 L46 116 Z"
        fill={p.paper}
      />
      {/* pin slots */}
      <g fill={p.ink}>
        <rect x="68" y="100" width="120" height="6" rx="2" />
        <rect x="80" y="112" width="96" height="6" rx="2" />
        <rect x="68" y="124" width="120" height="6" rx="2" />
      </g>
      {/* cable stub */}
      <rect x="94" y="148" width="68" height="20" rx="4" fill={p.paper} />
      <rect x="110" y="168" width="36" height="40" rx="6" fill={p.paper} />
      {/* motion lines / waveform */}
      <g stroke={p.accent} strokeWidth="6" strokeLinecap="round" fill="none">
        <path d="M32 60 Q56 48 80 60" />
        <path d="M176 60 Q200 48 224 60" />
        <path d="M28 40 Q60 26 92 40" opacity="0.5" />
        <path d="M164 40 Q196 26 228 40" opacity="0.5" />
      </g>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// D · TinyTV — micro CRT/screen w/ circuit body
// ─────────────────────────────────────────────────────────────
function IconTinyTV({ p = PALETTES.amber, radius = 64 }) {
  return (
    <svg viewBox="0 0 256 256" width="100%" height="100%">
      <rect x="0" y="0" width="256" height="256" rx={radius} fill={p.ink} />
      {/* tv body */}
      <rect x="36" y="56" width="184" height="148" rx="14" fill={p.paper} />
      {/* screen */}
      <rect x="52" y="74" width="152" height="100" rx="8" fill={p.ink} />
      {/* phosphor glow */}
      <rect x="60" y="82" width="136" height="84" rx="4" fill={p.accent} opacity="0.18" />
      {/* play triangle on screen */}
      <path d="M104 102 L148 124 L104 146 Z" fill={p.accent} />
      {/* control dot row */}
      <g fill={p.ink}>
        <circle cx="64" cy="190" r="5" />
        <circle cx="80" cy="190" r="5" />
        <rect x="100" y="186" width="56" height="8" rx="3" />
        <circle cx="176" cy="190" r="5" />
        <circle cx="192" cy="190" r="5" />
      </g>
      {/* legs */}
      <rect x="80" y="206" width="10" height="14" rx="2" fill={p.paper} />
      <rect x="166" y="206" width="10" height="14" rx="2" fill={p.paper} />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// E · Loop — cable loop forming a play-triangle pointer
// ─────────────────────────────────────────────────────────────
function IconLoop({ p = PALETTES.violet, radius = 64 }) {
  return (
    <svg viewBox="0 0 256 256" width="100%" height="100%">
      <rect x="0" y="0" width="256" height="256" rx={radius} fill={p.ink} />
      {/* loop ring */}
      <circle cx="128" cy="128" r="76" fill="none" stroke={p.paper} strokeWidth="14" strokeLinecap="round"
        strokeDasharray="380 80" transform="rotate(-30 128 128)" />
      {/* arrow head on the open end */}
      <path d="M186 86 L214 80 L196 102 Z" fill={p.paper} />
      {/* device square in the centre */}
      <rect x="98" y="98" width="60" height="60" rx="8" fill={p.paper} />
      <rect x="98" y="98" width="60" height="60" rx="8" fill={p.accent} opacity="0.18" />
      {/* play triangle inside */}
      <path d="M118 114 L146 128 L118 142 Z" fill={p.accent} />
      {/* corner pins */}
      <g fill={p.paper}>
        <rect x="92" y="104" width="6" height="14" rx="1.5" />
        <rect x="92" y="138" width="6" height="14" rx="1.5" />
        <rect x="158" y="104" width="6" height="14" rx="1.5" />
        <rect x="158" y="138" width="6" height="14" rx="1.5" />
      </g>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// F · Pixel — chunky pixel-art mini-computer
// ─────────────────────────────────────────────────────────────
function IconPixel({ p = PALETTES.phosphor, radius = 48 }) {
  // 16×16 grid: . blank, # paper, * accent, o ink (on paper)
  const map = [
    '................',
    '................',
    '.##############.',
    '.#............#.',
    '.#.##########.#.',
    '.#.#********#.#.',
    '.#.#**oo****#.#.',
    '.#.#**o*****#.#.',
    '.#.#**oo****#.#.',
    '.#.#********#.#.',
    '.#.##########.#.',
    '.#............#.',
    '.##############.',
    '...##......##...',
    '..####....####..',
    '................',
  ];
  return (
    <svg viewBox="0 0 256 256" width="100%" height="100%" shapeRendering="crispEdges">
      <rect x="0" y="0" width="256" height="256" rx={radius} fill={p.ink} />
      {map.map((row, y) =>
        row.split('').map((c, x) => {
          if (c === '.') return null;
          const fill = c === '#' ? p.paper : c === '*' ? p.accent : p.ink;
          return <rect key={`${x}-${y}`} x={x*16} y={y*16} width="16" height="16" fill={fill} />;
        })
      )}
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────
function IconBox({ size = 128, radius, children }) {
  return (
    <div style={{ width: size, height: size, borderRadius: radius ?? size * 0.22, overflow: 'hidden' }}>
      {children}
    </div>
  );
}

function AppIconRow({ Icon, palette }) {
  const sizes = [180, 120, 80, 40];
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 28 }}>
      {sizes.map((s) => (
        <div key={s} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
          <div style={{
            width: s, height: s, borderRadius: s * 0.225, overflow: 'hidden',
            boxShadow: '0 10px 30px rgba(0,0,0,.18)',
          }}>
            <Icon p={palette} />
          </div>
          <div className="mono" style={{ fontSize: 10, color: '#6b6358' }}>{s}×{s}</div>
        </div>
      ))}
    </div>
  );
}

function FaviconRow({ Icon, palette, label }) {
  const sizes = [64, 32, 16];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        background: '#ffffff', border: '1px solid #e5e1d8',
        borderRadius: '10px 10px 0 0', padding: '8px 12px',
        width: 240, fontSize: 12, color: '#3a342c',
      }}>
        <div style={{ width: 16, height: 16, borderRadius: 3, overflow: 'hidden', flex: '0 0 auto' }}>
          <Icon p={palette} radius={48} />
        </div>
        <div style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {label} · pi.local
        </div>
        <div style={{ width: 14, height: 14, opacity: 0.4, fontSize: 14, lineHeight: 1 }}>×</div>
      </div>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 18 }}>
        {sizes.map((s) => (
          <div key={s} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
            <div style={{
              width: s, height: s, borderRadius: s <= 16 ? 3 : 6, overflow: 'hidden',
              border: '1px solid rgba(0,0,0,.08)',
            }}>
              <Icon p={palette} radius={s <= 16 ? 24 : s <= 32 ? 32 : 48} />
            </div>
            <div className="mono" style={{ fontSize: 10, color: '#6b6358' }}>{s}px</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function CliWindow({ ascii, name = 'pi-wpe', subtitle = 'Pi Wallpaper Engine', accent = '#3DDC84', session }) {
  return (
    <div style={{
      width: '100%', height: '100%',
      background: '#0B130F', borderRadius: 10, overflow: 'hidden',
      display: 'flex', flexDirection: 'column',
      fontFamily: "'JetBrains Mono', ui-monospace, Menlo, monospace",
      boxShadow: '0 14px 40px rgba(0,0,0,.18)',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px',
        background: '#101A14', borderBottom: '1px solid rgba(255,255,255,.06)',
      }}>
        <div style={{ display: 'flex', gap: 6 }}>
          <span style={{ width: 11, height: 11, borderRadius: '50%', background: '#FF5F57' }} />
          <span style={{ width: 11, height: 11, borderRadius: '50%', background: '#FEBC2E' }} />
          <span style={{ width: 11, height: 11, borderRadius: '50%', background: '#28C840' }} />
        </div>
        <div style={{ flex: 1, textAlign: 'center', color: 'rgba(232,243,229,.5)', fontSize: 11 }}>
          pi@raspberrypi: ~ — {name}
        </div>
      </div>
      <div style={{
        flex: 1, padding: '18px 22px', color: '#C9E8C1', fontSize: 12, lineHeight: 1.35,
        whiteSpace: 'pre', overflow: 'hidden',
      }}>
        <span style={{ color: accent }}>{ascii}</span>
        {'\n'}
        <span style={{ color: '#7BA683' }}>  {subtitle}{'\n'}</span>
        <span style={{ color: '#7BA683' }}>  v0.4.2 · raspbian-bookworm{'\n\n'}</span>
        {session}
      </div>
    </div>
  );
}

Object.assign(window, {
  PALETTES,
  IconBoard, IconChip, IconHDMI, IconTinyTV, IconLoop, IconPixel,
  IconBox, AppIconRow, FaviconRow, CliWindow,
});
