// canvas.jsx — assembles all logo concepts on a DesignCanvas
const { useState } = React;

// ASCII variants — all evoke a tiny board/screen, not a math glyph
const ASCII_BOARD = String.raw`
  ┌──┬──┬──┬──┬──┬──┬──┐
  │··················│o
  │   ┌──────────┐   │
  │   │  ▶ play  │   │
  │   │  ▆▆▆▆▆▆  │   │
  │   └──────────┘   │
  │o                o│
  └──────────────────┘
`.trimEnd();

const ASCII_SCREEN = String.raw`
   ╔══════════════════╗
   ║                  ║
   ║      ▶▶▶▶▶       ║
   ║     ▆▆▆▆▆▆▆      ║
   ║                  ║
   ╚════[==o==]═══════╝
       ╱╲      ╱╲
`.trimEnd();

const ASCII_CHIP = String.raw`
   ┊  ┊  ┊  ┊  ┊  ┊
  ┌─────────────────┐
 ─┤ ░░░░░░░░░░░░░░  ├─
 ─┤ ░  ▶  P L A Y░  ├─
 ─┤ ░░░░░░░░░░░░░░  ├─
  └─────────────────┘
   ┊  ┊  ┊  ┊  ┊  ┊
`.trimEnd();

const ASCII_MINI = String.raw`
   ▗▄▄▄▄▄▄▄▄▖
   ▐ ▶ wpe ▌
   ▝▀▀▀▀▀▀▀▘
`.trimEnd();

function Cover() {
  return (
    <div style={{
      width: 1100, padding: '32px 36px',
      background: '#0E1116', color: '#F4EFE6', borderRadius: 14,
      fontFamily: 'Inter',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      boxShadow: '0 18px 50px rgba(14,17,22,.18)',
    }}>
      <div>
        <div className="mono" style={{ fontSize: 12, opacity: 0.6, letterSpacing: 0.4 }}>
          v0.2 · LOGO EXPLORATION
        </div>
        <div style={{ fontSize: 42, fontWeight: 700, letterSpacing: -0.5, marginTop: 6 }}>
          Pi Wallpaper Engine
        </div>
        <div style={{ fontSize: 15, opacity: 0.65, marginTop: 6, maxWidth: 580 }}>
          A wallpaper renderer for the Raspberry Pi. Six original marks anchored on the
          single-board-computer story — chip, board, screen, signal — never the raspberry trademark.
        </div>
      </div>
      <div style={{ display: 'flex', gap: 14 }}>
        <IconBox size={88} radius={20}><IconBoard p={PALETTES.phosphor} /></IconBox>
        <IconBox size={88} radius={20}><IconChip p={PALETTES.violet} /></IconBox>
        <IconBox size={88} radius={20}><IconTinyTV p={PALETTES.amber} /></IconBox>
      </div>
    </div>
  );
}

function AppArtboard({ Icon, palette, name, body }) {
  return (
    <div style={{
      width: '100%', height: '100%', background: '#F4EFE6',
      padding: '36px 32px', boxSizing: 'border-box',
      fontFamily: 'Inter', display: 'flex', flexDirection: 'column', gap: 26,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div className="mono" style={{ fontSize: 11, color: '#8a8174', letterSpacing: 0.4 }}>CONCEPT</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: '#0E1116', letterSpacing: -0.2 }}>{name}</div>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          {Object.entries(palette).map(([k, v]) => (
            <div key={k} title={v} style={{
              width: 22, height: 22, borderRadius: 6, background: v,
              border: '1px solid rgba(0,0,0,.06)',
            }} />
          ))}
        </div>
      </div>

      <div style={{
        display: 'flex', alignItems: 'center', gap: 24,
        padding: 24, background: '#fff', borderRadius: 14,
        border: '1px solid #e8e2d6',
      }}>
        <div style={{ width: 192, height: 192, borderRadius: 44, overflow: 'hidden',
          boxShadow: '0 14px 40px rgba(0,0,0,.18)' }}>
          <Icon p={palette} />
        </div>
        <div style={{ flex: 1, color: '#3a342c' }}>
          <div className="mono" style={{ fontSize: 11, color: '#8a8174' }}>192 × 192</div>
          <div style={{ fontSize: 14, marginTop: 6, lineHeight: 1.5 }}>{body}</div>
        </div>
      </div>

      <div>
        <div className="mono" style={{ fontSize: 11, color: '#8a8174', marginBottom: 14 }}>
          SCALE · 180 / 120 / 80 / 40
        </div>
        <AppIconRow Icon={Icon} palette={palette} />
      </div>

      <div style={{
        marginTop: 'auto', display: 'flex', alignItems: 'center', gap: 18,
        padding: 18, borderRadius: 12,
        background: 'linear-gradient(135deg, #2a2d3a 0%, #1a1d28 100%)',
      }}>
        {[64, 64, 64, 64].map((s, i) => (
          <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
            <div style={{ width: s, height: s, borderRadius: 14, overflow: 'hidden',
              boxShadow: '0 6px 16px rgba(0,0,0,.4)' }}>
              {i === 0 ? <Icon p={palette} /> : (
                <div style={{ width: '100%', height: '100%', background: ['#ff9f0a','#30d158','#5e5ce6'][i-1] }} />
              )}
            </div>
            <div className="mono" style={{ fontSize: 9, color: 'rgba(255,255,255,.7)' }}>
              {['pi-wpe','Files','Camera','Mail'][i]}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function WebArtboard({ Icon, palette, name }) {
  return (
    <div style={{
      width: '100%', height: '100%', background: '#F4EFE6',
      padding: '36px 32px', boxSizing: 'border-box',
      fontFamily: 'Inter', display: 'flex', flexDirection: 'column', gap: 24,
    }}>
      <div>
        <div className="mono" style={{ fontSize: 11, color: '#8a8174' }}>WEB FAVICON</div>
        <div style={{ fontSize: 22, fontWeight: 700, color: '#0E1116' }}>{name}</div>
      </div>

      <FaviconRow Icon={Icon} palette={palette} label="Pi Wallpaper" />

      <div style={{
        marginTop: 8, background: '#fff', border: '1px solid #e5e1d8',
        borderRadius: 10, padding: 12,
      }}>
        <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
          <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#FF5F57' }} />
          <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#FEBC2E' }} />
          <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#28C840' }} />
        </div>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8,
          background: '#f5f2eb', padding: '7px 12px', borderRadius: 18,
          fontSize: 12, color: '#3a342c',
        }}>
          <div style={{ width: 14, height: 14, borderRadius: 3, overflow: 'hidden' }}>
            <Icon p={palette} radius={48} />
          </div>
          <span className="mono" style={{ fontSize: 11 }}>pi.local:7878/library</span>
        </div>
      </div>

      <div style={{
        background: '#fff', border: '1px solid #e5e1d8', borderRadius: 10, padding: 10,
        display: 'flex', alignItems: 'center', gap: 16, fontSize: 12, color: '#3a342c',
      }}>
        {['pi-wpe', 'Steam', 'Reddit', 'HN', 'Discord'].map((t, i) => (
          <div key={t} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{
              width: 14, height: 14, borderRadius: 3, overflow: 'hidden',
              background: ['transparent','#1b2838','#ff4500','#ff6600','#5865f2'][i],
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: '#fff', fontSize: 8, fontWeight: 700,
            }}>
              {i === 0 ? <Icon p={palette} radius={48} /> : t[0]}
            </div>
            <span>{t}</span>
          </div>
        ))}
      </div>

      <div style={{
        background: '#1a1d28', borderRadius: 10, padding: 12, marginTop: 'auto',
      }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10,
          background: '#2a2d3a', borderRadius: '8px 8px 0 0',
          padding: '8px 12px', width: 240,
        }}>
          <div style={{ width: 16, height: 16, borderRadius: 3, overflow: 'hidden' }}>
            <Icon p={palette} radius={48} />
          </div>
          <div style={{ fontSize: 12, color: '#e5e1d8' }}>Pi Wallpaper · Library</div>
        </div>
      </div>
    </div>
  );
}

function CliArtboard({ ascii, palette, name, kind }) {
  const sessions = {
    install: (
      <>
        <span style={{ color: '#7BA683' }}>$ </span>
        <span style={{ color: '#E8F3E5' }}>pi-wpe install 2107834502</span>
        {'\n'}
        <span style={{ color: '#7BA683' }}>{'⠋ '}fetching workshop bundle…  </span>
        <span style={{ color: palette.accent }}>87%</span>
        {'\n'}
        <span style={{ color: '#7BA683' }}>✓ installed   </span>
        <span style={{ color: '#C9E8C1' }}>Neon Genesis Skyline · 38.4 MB</span>
        {'\n\n'}
        <span style={{ color: '#7BA683' }}>$ </span>
        <span style={{ color: '#E8F3E5' }}>pi-wpe play --loop</span>
        {'\n'}
        <span style={{ color: palette.accent }}>▶ playing</span>
        <span style={{ color: '#7BA683' }}>{' '}on HDMI-1 · 1920×1080 · 30fps</span>
        {'\n'}
        <span style={{ color: '#7BA683' }}>$ </span>
        <span style={{ color: '#C9E8C1', animation: 'blink 1s steps(2) infinite' }}>▍</span>
      </>
    ),
    help: (
      <>
        <span style={{ color: '#7BA683' }}>$ </span>
        <span style={{ color: '#E8F3E5' }}>pi-wpe --help</span>
        {'\n\n'}
        <span style={{ color: palette.accent }}>USAGE</span>
        {'\n'}
        <span style={{ color: '#C9E8C1' }}>  pi-wpe </span>
        <span style={{ color: '#7BA683' }}>{'<command>'}</span>
        <span style={{ color: '#C9E8C1' }}> [options]</span>
        {'\n\n'}
        <span style={{ color: palette.accent }}>COMMANDS</span>
        {'\n'}
        <span style={{ color: '#C9E8C1' }}>  install     </span>
        <span style={{ color: '#7BA683' }}>download a workshop item</span>
        {'\n'}
        <span style={{ color: '#C9E8C1' }}>  play        </span>
        <span style={{ color: '#7BA683' }}>start the renderer</span>
        {'\n'}
        <span style={{ color: '#C9E8C1' }}>  ls          </span>
        <span style={{ color: '#7BA683' }}>list installed wallpapers</span>
        {'\n'}
        <span style={{ color: '#C9E8C1' }}>  stop        </span>
        <span style={{ color: '#7BA683' }}>kill the renderer</span>
        {'\n\n'}
        <span style={{ color: '#7BA683' }}>$ </span>
        <span style={{ color: '#C9E8C1', animation: 'blink 1s steps(2) infinite' }}>▍</span>
      </>
    ),
  };
  return (
    <div style={{
      width: '100%', height: '100%', background: '#F4EFE6',
      padding: '36px 32px', boxSizing: 'border-box',
      fontFamily: 'Inter', display: 'flex', flexDirection: 'column', gap: 22,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div className="mono" style={{ fontSize: 11, color: '#8a8174' }}>CLI · ASCII MARK</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: '#0E1116' }}>{name}</div>
        </div>
        <div className="mono" style={{
          fontSize: 11, color: '#8a8174',
          padding: '4px 8px', background: '#fff', borderRadius: 4,
          border: '1px solid #e8e2d6',
        }}>
          {kind}
        </div>
      </div>

      <div style={{ flex: 1, minHeight: 0 }}>
        <CliWindow ascii={ascii} accent={palette.accent} session={sessions[kind] || sessions.install} />
      </div>

      <div style={{
        background: '#fff', border: '1px solid #e8e2d6', borderRadius: 10,
        padding: '14px 18px', display: 'flex', gap: 20, alignItems: 'center',
      }}>
        <div className="mono" style={{ fontSize: 11, color: '#8a8174', minWidth: 140 }}>
          NO-COLOR FALLBACK
        </div>
        <pre className="mono" style={{
          margin: 0, fontSize: 10, lineHeight: 1.15, color: '#0E1116',
          whiteSpace: 'pre',
        }}>{ascii}</pre>
      </div>
    </div>
  );
}

function App() {
  const concepts = [
    {
      id: 'board', name: 'A · Board', Icon: IconBoard, palette: PALETTES.phosphor,
      blurb: 'Top-down silhouette of a single-board computer with GPIO header. The SoC die plays a video. Most literal — instantly reads as "Pi".',
    },
    {
      id: 'chip', name: 'B · Chip', Icon: IconChip, palette: PALETTES.violet,
      blurb: 'IC chip whose die is a tiny screen mid-playback. Confident, geometric, and survives at very small sizes.',
    },
    {
      id: 'hdmi', name: 'C · HDMI', Icon: IconHDMI, palette: PALETTES.cyan,
      blurb: 'HDMI plug with motion lines flowing out. Captures the "video output" half of the product — what the Pi sends to your TV.',
    },
    {
      id: 'tinytv', name: 'D · Tiny TV', Icon: IconTinyTV, palette: PALETTES.amber,
      blurb: 'A pocket television showing a playing video. The friendliest of the set; works well as a launcher icon.',
    },
    {
      id: 'loop', name: 'E · Loop', Icon: IconLoop, palette: PALETTES.violet,
      blurb: 'A cable looping around a small device, terminating in a play arrow. Conveys the never-ending wallpaper loop.',
    },
    {
      id: 'pixel', name: 'F · Pixel', Icon: IconPixel, palette: PALETTES.phosphor,
      blurb: 'Chunky pixel-art mini-computer. Built for the 16×16 favicon and pairs naturally with the CLI ASCII mark.',
    },
  ];

  return (
    <>
      <style>{`@keyframes blink {50% { opacity: 0; }}`}</style>
      <DesignCanvas
        cover={<Cover />}
        sidecarPath=".design-canvas.state.json"
      >
        <DCSection id="overview" title="Overview" subtitle="Six concepts — small computer, screen, signal. No π glyph, no raspberry.">
          {concepts.map((c) => (
            <DCArtboard key={c.id} id={`ov-${c.id}`} label={c.name} width={300} height={420}>
              <div style={{
                width: '100%', height: '100%', padding: '28px 24px', boxSizing: 'border-box',
                background: c.palette.paper, fontFamily: 'Inter',
                display: 'flex', flexDirection: 'column', gap: 18,
              }}>
                <div style={{ width: 168, height: 168, borderRadius: 38, overflow: 'hidden',
                  alignSelf: 'center',
                  boxShadow: '0 16px 40px rgba(0,0,0,.18)' }}>
                  <c.Icon p={c.palette} />
                </div>
                <div>
                  <div style={{ fontSize: 18, fontWeight: 700, color: c.palette.ink }}>{c.name.split(' · ')[1]}</div>
                  <div style={{ fontSize: 12, lineHeight: 1.5, color: c.palette.ink, opacity: 0.7, marginTop: 6 }}>
                    {c.blurb}
                  </div>
                </div>
                <div style={{ marginTop: 'auto', display: 'flex', gap: 6 }}>
                  {Object.values(c.palette).map((v, i) => (
                    <div key={i} style={{
                      flex: 1, height: 6, borderRadius: 3, background: v,
                      border: '1px solid rgba(0,0,0,.06)',
                    }} />
                  ))}
                </div>
              </div>
            </DCArtboard>
          ))}
        </DCSection>

        <DCSection id="app" title="App icon" subtitle="Launcher icon — iOS / macOS / Linux desktop">
          {concepts.map((c) => (
            <DCArtboard key={c.id} id={`app-${c.id}`} label={c.name} width={620} height={720}>
              <AppArtboard Icon={c.Icon} palette={c.palette} name={c.name} body={c.blurb} />
            </DCArtboard>
          ))}
        </DCSection>

        <DCSection id="web" title="Web favicon" subtitle="Tab, address bar, bookmarks — 16 / 32 / 64px">
          {concepts.map((c) => (
            <DCArtboard key={c.id} id={`web-${c.id}`} label={c.name} width={560} height={620}>
              <WebArtboard Icon={c.Icon} palette={c.palette} name={c.name} />
            </DCArtboard>
          ))}
        </DCSection>

        <DCSection id="cli" title="CLI mark" subtitle="ASCII partner shown on `pi-wpe` startup / --help banner">
          <DCArtboard id="cli-board" label="A · Board (ASCII)" width={620} height={620}>
            <CliArtboard ascii={ASCII_BOARD} palette={PALETTES.phosphor} name="A · Board" kind="install" />
          </DCArtboard>
          <DCArtboard id="cli-chip" label="B · Chip (ASCII)" width={620} height={620}>
            <CliArtboard ascii={ASCII_CHIP} palette={PALETTES.violet} name="B · Chip" kind="help" />
          </DCArtboard>
          <DCArtboard id="cli-screen" label="D · TinyTV (ASCII)" width={620} height={620}>
            <CliArtboard ascii={ASCII_SCREEN} palette={PALETTES.amber} name="D · Tiny TV" kind="install" />
          </DCArtboard>
          <DCArtboard id="cli-mini" label="G · Minimal" width={620} height={620}>
            <CliArtboard ascii={ASCII_MINI} palette={PALETTES.cyan} name="G · Minimal" kind="help" />
          </DCArtboard>
        </DCSection>

        <DCSection id="hero" title="In the wild" subtitle="The mark, shown where it actually lives">
          <DCArtboard id="hero-tv" label="On the TV (idle screen)" width={960} height={540}>
            <div style={{
              width: '100%', height: '100%',
              background: 'radial-gradient(120% 80% at 50% 40%, #0c1f14 0%, #050a07 70%, #000 100%)',
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
              gap: 26, color: '#F4EFE6', fontFamily: 'Inter',
            }}>
              <div style={{ width: 160, height: 160, borderRadius: 36, overflow: 'hidden',
                boxShadow: '0 24px 60px rgba(61,220,132,.25)' }}>
                <IconBoard p={PALETTES.phosphor} />
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 38, fontWeight: 700, letterSpacing: -0.5 }}>Pi Wallpaper Engine</div>
                <div className="mono" style={{ fontSize: 13, opacity: 0.6, marginTop: 8 }}>
                  ready · 24 wallpapers · HDMI-1
                </div>
              </div>
              <div style={{ display: 'flex', gap: 12, marginTop: 8 }}>
                {['Library', 'Browse', 'Settings'].map((t, i) => (
                  <div key={t} style={{
                    padding: '10px 22px', borderRadius: 999,
                    background: i === 0 ? '#3DDC84' : 'rgba(244,239,230,.08)',
                    color: i === 0 ? '#0B130F' : '#F4EFE6', fontSize: 13, fontWeight: 600,
                  }}>{t}</div>
                ))}
              </div>
            </div>
          </DCArtboard>

          <DCArtboard id="hero-term" label="Boot terminal" width={720} height={540}>
            <div style={{ width: '100%', height: '100%', padding: 28, boxSizing: 'border-box', background: '#0E1116' }}>
              <CliWindow
                ascii={ASCII_BOARD}
                accent="#3DDC84"
                subtitle="Pi Wallpaper Engine"
                session={(
                  <>
                    <span style={{ color: '#7BA683' }}>$ </span>
                    <span style={{ color: '#E8F3E5' }}>systemctl status pi-wpe</span>
                    {'\n'}
                    <span style={{ color: '#3DDC84' }}>● active </span>
                    <span style={{ color: '#C9E8C1' }}>(running) since Mon 2026-05-12 09:14:22 UTC</span>
                    {'\n'}
                    <span style={{ color: '#7BA683' }}>  ↳ rendering </span>
                    <span style={{ color: '#C9E8C1' }}>"Neon Genesis Skyline" @ 30fps</span>
                    {'\n\n'}
                    <span style={{ color: '#7BA683' }}>$ </span>
                    <span style={{ color: '#C9E8C1', animation: 'blink 1s steps(2) infinite' }}>▍</span>
                  </>
                )}
              />
            </div>
          </DCArtboard>
        </DCSection>
      </DesignCanvas>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
